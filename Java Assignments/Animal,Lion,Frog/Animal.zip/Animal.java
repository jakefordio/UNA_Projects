public class Animal {
    private String genus;
    private String species;
    private double weight;
    private boolean tail;
    
    public Animal() {
    	
    }
     
    public Animal(String genus, String species) {
        this.genus = genus;
        this.species = species;
    }
     
    public void setWeight(double weight) {
        this.weight = weight;
    }
     
    public double getWeight() {
        return this.weight;
    }
     
    public void setTail(boolean tail) {
        this.tail = tail;
    }
     
    public boolean getTail() {
        return this.tail;
    }
}