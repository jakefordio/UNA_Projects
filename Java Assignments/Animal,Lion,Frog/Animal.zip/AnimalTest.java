import java.util.ArrayList;

public class AnimalTest {
	public static void main (String [] args) {
		ArrayList<Animal> a = createList();
		for(int i = 0; i <a.size(); i++) {
			System.out.println(a.get(i).getWeight() + " lbs");
		}
		
		ArrayList<Lion> l = createList();
		for(int k = 0; k<3; k++) {
			System.out.println(l.get(k).getName());
		}
		
	}
	
	private static ArrayList createList() {
		ArrayList<Animal> createList = new ArrayList<Animal>();
		createList.add(new Lion(530, "Leo I"));
		createList.add(new Lion(560, "Leo II"));
		createList.add(new Lion(590, "Leo III"));
		createList.add(new Frog(7, "Freddie"));
		
		return createList;
	}
}
