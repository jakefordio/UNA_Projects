public class Frog extends Animal{
    private String name;
     
  public Frog () {
    	
    }
    
    public Frog (double weight, String name) {
        super("Lithobates","Catesbeianus");
        this.name = name;
        setWeight(weight);
        setTail(false);
    }
     
    public void setName (String  name) {
        this.name = name;
    }
     
    public String getName() {
        return this.name;
    }
}