public class Lion extends Animal {
    private String name;
    
    public Lion () {
    	
    }
   
    public Lion (double weight, String name) {
        super("Panthera", "Leo");
        this.name = name;
        setWeight(weight);
        setTail(true);
    }
    
    public void setName(String name) {
        this.name = name;
    }
     
    public String getName() {
        return this.name;
    }
     
}